﻿using Mapper.DataMapper;
using Mapper.DB;
using Mapper.SQLMapper;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OdejzdyAutobusu.Controllers
{
    public class UsersController : Controller
    {
        public List<Users> users = new List<Users>();
        // GET: Users
        public ActionResult Index()
        {
            return View(UsersSQLMapper.GetUsers().ToList());
        }

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(Users user)
        {
            var usr = Mapper.SQLMapper.UsersSQLMapper.Where(user.email, user.pwd).FirstOrDefault();
            if (usr != null)
            {
                Session["UserID"] = usr.id.ToString();
                Session["Email"] = usr.email.ToString();
                Session["Name"] = usr.firstname.ToString();
                Session["LastName"] = usr.lastname.ToString();
                if (usr.permision == 'A') Session["Perm"] = usr.permision.ToString();
                return RedirectToAction("LoggedIn");
            }
            else
            {
                ModelState.AddModelError("", "Email or password incorrected.");
            }
            return View();
        }

        public ActionResult LoggedIn()
        {
            if (Session["UserID"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Login");
            }
        }
    }
}