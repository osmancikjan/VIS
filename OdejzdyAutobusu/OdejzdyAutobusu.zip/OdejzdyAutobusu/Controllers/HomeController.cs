﻿using Mapper.DataMapper;
using Mapper.SQLMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OdejzdyAutobusu.Controllers
{
    public class HomeController : Controller
    {
        public static List<Stops> stops = new List<Stops>();

        public ActionResult Index()
        {
            ViewData.Clear();
            stops = StopsSQLMapper.GetStops().ToList();
            foreach(var item in stops)
            {
                ViewData.Add(item.id.ToString(), item.sname);
            }
            return View();
        }

        public ActionResult Stops()
        {
            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}