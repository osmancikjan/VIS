﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Obecné informace o sestavení jsou řízeny prostřednictvím následující
// sady atributů. Chcete-li změnit informace související se sestavením,
// změňte hodnoty těchto atributů.
[assembly: AssemblyTitle("OdejzdyAutobusu")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("OdejzdyAutobusu")]
[assembly: AssemblyCopyright("Copyright ©  2017")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Nastavení atributu ComVisible na hodnotu false má za výsledek, že typy v tomto sestavení nejsou viditelné
// pro komponenty modelu COM. Potřebujete-li přistupovat k typu v tomto sestavení
// z modelu COM, nastavte atribut ComVisible pro daný typ na hodnotu true.
[assembly: ComVisible(false)]

// Následující GUID je určen pro ID knihovny typelib, pokud je tento projekt zpřístupněn modulu COM.
[assembly: Guid("b6eba759-fbf1-411f-b4e5-b0521e207f28")]

// Informace o verzi sestavení jsou tvořeny následujícími čtyřmi hodnotami:
//
//      Hlavní verze
//      Podverze
//      Číslo sestavení
//      Revize
//
// Můžete zadat všechny tyto hodnoty, nebo použít výchozí hodnoty pro číslo revize a sestavení
// zadáním znaku * jako v příkladu níže:
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
