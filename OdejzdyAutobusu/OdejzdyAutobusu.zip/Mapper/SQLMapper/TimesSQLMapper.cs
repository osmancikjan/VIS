﻿using Mapper.DataMapper;
using Mapper.DB;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SqlClient;


namespace Mapper.SQLMapper
{
    class TimesSQLMapper
    {
        private static List<Times> times = new List<Times>();

        public static string SQL_INSERT = "INSERT INTO Times VALUES (@id, @s_id, @b_id, @leaving, @delay, @next_stop, @last_known_stop)";
        public static string SQL_SINGLE_SELECT = "SELECT * FROM Times WHERE id = @id";
        public static string SQL_SELECT = "SELECT * FROM Times";
        public static string SQL_UPDATE = "UPDATE Times SET s_id = @s_id, b_id = @b_id, leaving = @leaving, delay = @delay, next_stop = @next_stop, last_known_stop = @last_known_stop WHERE id=@id";

        public static List<Times> Times { get => times; set => times = value; }

        // INSERT time
        // -----------

        public static int Insert(Times time)
        {
            Database db;
            db = new Database();
            db.Connect();

            SqlCommand command = db.CreateCommand(SQL_INSERT);
            PrepareCommand(command, time);
            int ret = db.ExecuteNonQuery(command);

            db.Close();

            return ret;
        }

        // UPDATE USER
        // -----------

        public static int Update(Times time)
        {
            Database db;

            db = new Database();
            db.Connect();

            SqlCommand command = db.CreateCommand(SQL_UPDATE);
            PrepareCommand(command, time);
            int ret = db.ExecuteNonQuery(command);

            db.Close();

            return ret;
        }

        // GET ALL Times
        // -------------

        public static Collection<Times> GetTimes()
        {
            Database db;
            db = new Database();
            db.Connect();

            SqlCommand command = db.CreateCommand(SQL_SELECT);

            SqlDataReader reader = db.Select(command);

            Collection<Times> times = Read(reader);
            reader.Close();

            db.Close();

            return times;
        }

        // GET time by ID
        // --------------

        public static Collection<Times> GetTime(int id)
        {
            Database db;
            db = new Database();
            db.Connect();

            SqlCommand command = db.CreateCommand(SQL_SINGLE_SELECT);
            PrepareCommand(command, id);
            SqlDataReader reader = db.Select(command);

            Collection<Times> times = Read(reader);
            reader.Close();

            db.Close();

            return times;
        }

        // PREPARE COMMAND
        // ---------------

        private static void PrepareCommand(SqlCommand command, Times time)
        {
            
        }

        private static void PrepareCommand(SqlCommand command, int id)
        {
            command.Parameters.AddWithValue("@id", id);
        }

        // READ
        // ----

        private static Collection<Times> Read(SqlDataReader reader)
        {
            Collection<Times> times = new Collection<Times>();

            while (reader.Read())
            {
                int i = -1;
                Times time = new Times();
                time.id = reader.GetInt32(++i);
                time.s_id = reader.GetInt32(++i);
                time.b_id = reader.GetInt32(++i);
                time.leaving = reader.GetDateTime(++i);
                time.delay = reader.GetInt32(++i);
                time.next_stop = reader.GetInt32(++i);
                time.last_known_stop = reader.GetInt32(++i);
                times.Add(time);
            }
            return times;
        }
    }
}
