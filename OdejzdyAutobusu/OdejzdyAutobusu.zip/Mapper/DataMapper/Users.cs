﻿namespace Mapper.DataMapper
{
    public class Users
    {
        public int id { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string email { get; set; }
        public string pwd { get; set; }
        public char permision { get; set; }
    }
}
/*[Key, Required(ErrorMessage = "ID uživatele je vyžadováno!")]
        public int id { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        [Required(ErrorMessage = "email uživatele je vyžadován!"), DataType(System.ComponentModel.DataAnnotations.DataType.EmailAddress)]
        public string email { get; set; }
        [Required(ErrorMessage = "Heslo je vyžadováno!", AllowEmptyStrings = false), DataType(System.ComponentModel.DataAnnotations.DataType.Password)]
        public string pwd { get; set; }
        public char permision { get; set; }
*/