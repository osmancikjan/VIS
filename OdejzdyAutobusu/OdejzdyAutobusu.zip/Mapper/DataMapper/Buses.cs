﻿namespace Mapper.DataMapper
{
    public class Buses
    {
        public int lnumber { get; set; }
        public int sfrom { get; set; }
        public int sto { get; set; }
    }
}
