﻿using System.Collections.Generic;

namespace Mapper.DataMapper
{
    public class Stops
    {
        public List<Stops> data;
        public int id { get; set; }
        public string sname { get; set; }
    }
}
